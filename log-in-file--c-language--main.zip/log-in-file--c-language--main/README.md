# log-in-file--c-language-
this is a sample of a log in interface created with C
feel free to modify it and comment below.
its made of purely c
